#include "main.h"

// --- Prototypes ---
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void DoStep(void);
uint8_t isSwitchPressed(uint16_t GPIO_Pin);

// --- Defines ---
#define STEP_PIN  GPIO_PIN_6
#define DIR_PIN   GPIO_PIN_7
#define EN_PIN    GPIO_PIN_0
#define LIMIT1    GPIO_PIN_3  // PB3
#define LIMIT2    GPIO_PIN_4  // PB4

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    // Enable Motor
    HAL_GPIO_WritePin(GPIOB, EN_PIN, GPIO_PIN_RESET);

    while (1) {
        // --- 1. FORWARD SCAN ---
        HAL_GPIO_WritePin(GPIOA, DIR_PIN, GPIO_PIN_SET);

        // Loop until a switch is pressed
        while(!isSwitchPressed(LIMIT1) && !isSwitchPressed(LIMIT2)) {
            DoStep();
        }

        // --- 2. STOP & REVERSE ---
        HAL_Delay(500);
        HAL_GPIO_WritePin(GPIOA, DIR_PIN, GPIO_PIN_RESET);
        HAL_Delay(500);

        // --- 3. REVERSE SCAN ---
        while(!isSwitchPressed(LIMIT1) && !isSwitchPressed(LIMIT2)) {
            DoStep();
        }

        HAL_Delay(500);
    }
}

// --- Logic Helpers ---
void DoStep(void) {
    HAL_GPIO_WritePin(GPIOA, STEP_PIN, GPIO_PIN_SET);
    HAL_Delay(2);
    HAL_GPIO_WritePin(GPIOA, STEP_PIN, GPIO_PIN_RESET);
    HAL_Delay(2);
}

uint8_t isSwitchPressed(uint16_t GPIO_Pin) {
    // Returns 1 if pressed (assuming switch pulls to GND)
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_Pin) == GPIO_PIN_RESET) {
        HAL_Delay(20); // Debounce
        if (HAL_GPIO_ReadPin(GPIOB, GPIO_Pin) == GPIO_PIN_RESET) {
            return 1;
        }
    }
    return 0;
}

// --- System Init ---
void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 8;
    RCC_OscInitStruct.PLL.PLLN = 100;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3);
}

static void MX_GPIO_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE(); // Added for safety

    // Motor Outputs
    GPIO_InitStruct.Pin = STEP_PIN | DIR_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = EN_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Limit Switch Inputs
    GPIO_InitStruct.Pin = LIMIT1 | LIMIT2;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void Error_Handler(void) { while(1); }
