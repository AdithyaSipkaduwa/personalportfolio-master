/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "stm32f4xx_it.h"

/******************************************************************************/
/* Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/

void NMI_Handler(void) { while (1); }
void HardFault_Handler(void) { while (1); }
void MemManage_Handler(void) { while (1); }
void BusFault_Handler(void) { while (1); }
void UsageFault_Handler(void) { while (1); }
void SVC_Handler(void) { }
void DebugMon_Handler(void) { }
void PendSV_Handler(void) { }

void SysTick_Handler(void)
{
  HAL_IncTick();
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/******************************************************************************/

/**
  * @brief This function handles DMA2 stream0 global interrupt.
  * NOTE: DMA IS NOT USED, SO THIS HANDLER IS COMMENTED OUT TO PREVENT ERRORS.
  */
void DMA2_Stream0_IRQHandler(void)
{
  /* DMA is not configured in your project, so we do not call HAL_DMA_IRQHandler.
     If you ever need DMA, you must define the handle in main.c and uncomment the line below.
     HAL_DMA_IRQHandler(&hdma_adc1);
  */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
